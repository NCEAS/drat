library(testthat)
test_package("dataone")
