## ------------------------------------------------------------------------
library(dataone)
library(curl)
cn <- CNode("PROD")
queryParamList <- list(q="id:doi*", rows="2", fq="abstract:chlorophyll", fl="id,title,dateUploaded,abstract,datasource,size")
result <- query(cn, queryParamList, as="list")

## ------------------------------------------------------------------------
result[[1]]$title

## ------------------------------------------------------------------------
ids <- lapply(result, function(x) {
  cat(sprintf("id: %s\n", x$id))
  cat(sprintf("origin member node: %s\n", x$datasource))
  cat(sprintf("title: %s\n", x$title))
  cat(sprintf("date uploaded: %s\n", x$dateUploaded))
  x$id
})

## ------------------------------------------------------------------------
cn <- CNode("PROD")
queryParams <- result <- query(cn, queryParamList, as="data.frame", parse=FALSE)
result <- query(cn, queryParamList, as="data.frame", parse=FALSE)

## ------------------------------------------------------------------------
result[,'id']

## ------------------------------------------------------------------------
cn <- CNode("PROD")
queryParams <- 'q=id:*&fl=id,title&fq="datasource:urn:node:KNB"&rows=5'
result <- query(cn, queryParams, as="data.frame", parse=FALSE)
result[,'id']

