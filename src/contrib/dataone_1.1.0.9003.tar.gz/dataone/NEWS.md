# Version 1.1.0.9001 (2015-05-29)

## New features and functions

* Updated query() to add possible return values of R list or data.frame

* added uploadDataObject that can upload a single DataObject to DataONE

* added uploadDataPackage that can upload all objects that have been added to a DataPackage

# Version 1.1.0.9002 (2015-06-04)
## Bug fixes

* query() now returns correctly if no query results found and data.frame was requested
