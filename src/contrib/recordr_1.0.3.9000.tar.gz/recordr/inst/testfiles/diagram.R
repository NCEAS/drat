grViz("
	digraph causal {
      
      # Nodes
      node [shape = plaintext]
      A [label = 'Age']
      R [label = 'Retained\n Placenta']
      M [label = 'Metritis']
      O [label = 'Cistic ovarian\n disease']
      F [label = 'Fertility']
      
      # Edges
      edge [color = black,
      arrowhead = vee]
      rankdir = LR
      A->F
      A->O
      A->R
      R->O
      R->M
      M->O
      O->F
      M->F
      
      # Graph
      graph [overlap = true, fontsize = 10]
      }")