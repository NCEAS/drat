#
#   This work was created by the National Center for Ecological Analysis and Synthesis.
#
#     Copyright 2015 Regents of the University of California
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

#' An RDF Parser object
#' @description The Parser class provides methods to parse RDF content into a Redland
#' RDF model.
#' @slot librdf_parser A redland parser object
#' @rdname Parser-class
#' @include redland.R
#' @include World.R
#' @include Model.R
#' @keywords classes
#' @exportClass Serializer
#' @examples
#' \dontrun{
#' parser <- new("Parser", world, name, mimeType, typeUri)
#' parserIntoModel(parser, uri, baseUri, model)
#' }
setClass("Parser", slots = c(librdf_parser = "_p_librdf_parser_s"))

#' Initialize a Parser object.
#' @description A Parser object is initialized for a specific RDF serialization.
#' @details The serialization format that are supported by 
#' @param .Object the Parser object
#' @param world a World object
#' @param name name of the parser factory to use
#' @param mimeType a mime type of the syntax of the model
#' @param typeUri a URI for the syntax of the model
#' @return the Parser object
#' @export
setMethod("initialize", signature = "Parser", definition = function(.Object, world, name="rdfxml", mimeType="application/rdf+xml", typeUri=as.character(NA)) {
  # Ensure that all provided params are not null
  stopifnot(!is.null(world))
  
  if(is.na(typeUri)) {
    librdf_uri <- librdf_new_uri(world@librdf_world, "")
  } else {
    librdf_uri <- librdf_new_uri(world@librdf_world, typeUri)
  }
  
  # Create the underlying redland statement object
  .Object@librdf_parser <- librdf_new_parser(world@librdf_world,
                                             name,
                                             mimeType,
                                             librdf_uri);
  return(.Object)
})

#' Parse the contents of a file into a model
#' @description The contents of a the specified file are read and parsed into the initialized
#' Parser object
#' @details The parser factory name specified during initialization determines how the content is
#' parsed, for example, if 'rdfxml' was specified during parser initialization, then the parser
#' expects RDF/XML content as specified in the W3C recommendation (http://www.we3.org/TR/REC-rdf-syntax)
#' @param .Object a Parser object 
#' @param world a World object
#' @param filePath a file that contains the RDF content
#' @param model a Model object to parse the RDF content into
#' @param ... baseUri a base URI (i.e. XML base) to apply to the model
#' @export
setGeneric("parseFileIntoModel", function(.Object, world, filePath, model, ...) {
  standardGeneric("parseFileIntoModel")
})

#' @describeIn Parser
#' #' @param .Object a Parser object 
#' @param world a World object
#' @param filePath a file that contains the RDF content
#' @param model a Model object to parse the RDF content into
#' @param baseUri a base URI (i.e. XML base) to apply to the model
setMethod("parseFileIntoModel", signature("Parser", "World", "character", "Model"), function(.Object, world, filePath, model, baseUri=as.character(NA)) {
  stopifnot(!is.null(model))
  
  if(is.na(baseUri)) {
    librdf_uri <- NULL
  } else {
    librdf_uri <- librdf_new_uri(world@librdf_world, baseUri)
  }
  
  # Construct a file URI of the input file name
  err <- try(absFilePath <- normalizePath(filePath, mustWork = TRUE))
  stopifnot (!class(err) == "try-error")
  
  fileUri = sprintf("file://%s", absFilePath)
  contentUri <- librdf_new_uri(world@librdf_world, fileUri)
  status <- librdf_parser_parse_into_model(.Object@librdf_parser, contentUri, NULL, model@librdf_model)
  
})


#' Free memory used by a librdf parser
#' @details After freeNode is called, the Node object is no longer usable and should
#' be deleted  \code{"rm(nodeName)"} and a new object created.
#' @param .Object a Node object
#' @export
setGeneric("freeParser", function(.Object) {
  standardGeneric("freeParser")
})

#' @describeIn Parser
setMethod("freeParser", signature("Parser"), function(.Object) {
  librdf_free_parser(.Object@librdf_parser)
})
