#library(rprov)
#library(utils)

print("this is my test script")

#myFish <- read.csv("~/Data/fish.csv")
#print(myFish)

#source("/Users/slaughter/Projects/R/rprov/examples/userScript2.R", echo = TRUE)
source("/home/slaughter/git/recordr/examples/userScript2.R")

