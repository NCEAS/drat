library(testthat) 
library(codyn)
test_check("codyn")
