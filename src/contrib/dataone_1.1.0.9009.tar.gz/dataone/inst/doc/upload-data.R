## ---- eval=FALSE---------------------------------------------------------
#  library(dataone)
#  library(datapackage)
#  library(uuid)
#  dp <- new("DataPackage")
#  sampleData <- system.file("extdata/sample.csv", package="dataone")
#  cn <- CNode("STAGING")
#  mn <- getMNode(cn, "urn:node:mnStageUCSB2")
#  # Create a unique id string for the data object in a standard format
#  dataId  <- paste("urn:uuid:", UUIDgenerate(), sep="")
#  dataObj <- new("DataObject", id=dataId, format="text/csv", file=sampleData)
#  dataObj <- setPublicAccess(dataObj)
#  sampleEML <- system.file("extdata/sample-eml.xml", package="dataone")
#  # Create a unique id string for the data object in a standard format
#  # Alternatively DOI string could used using "generateIdentifier(mn, scheme="DOI")"
#  metadataId <- paste("urn:uuid:", UUIDgenerate(), sep="")
#  metadataObj <- new("DataObject", id=metadataId, format="eml://ecoinformatics.org/eml-2.1.1", file=sampleEML)
#  metadataObj <- setPublicAccess(metadataObj)
#  addData(dp, metadataObj)
#  addData(dp, dataObj, metadataObj)
#  d1c <- D1Client(env="STAGING", mNodeid="urn:node:mnStageUCSB2")
#  packageId <- uploadDataPackage(d1c, dp, replicate=TRUE, public=TRUE, numberReplicas=2)

## ----eval=F--------------------------------------------------------------
#  library(dataone)
#  library(datapackage)
#  dp <- new("DataPackage")

## ----eval=F--------------------------------------------------------------
#  library(uuid)
#  sampleData <- system.file("extdata/sample.csv", package="dataone")
#  dataId <- paste("urn:uuid:", UUIDgenerate(), sep="")
#  dataObj <- new("DataObject", id=dataId, format="text/csv", file=sampleData)

## ----eval=F--------------------------------------------------------------
#  dataObj <- setPublicAccess(dataObj)

## ----eval=F--------------------------------------------------------------
#  accessRules <- data.frame(subject="uid=jsmith,o=NCEAS,dc=ecoinformatics,dc=org", permission="changePermission")
#  sciDataObj <- addAccessRule(dataObj, accessRules)

## ----eval=F--------------------------------------------------------------
#  sampleEML <- system.file("extdata/sample-eml.xml", package="dataone")
#  metadataObj <- new("DataObject", format="eml://ecoinformatics.org/eml-2.1.1", file=sampleEML)

## ---- eval=FALSE---------------------------------------------------------
#  cn <- CNode("STAGING")
#  mn <- getMNode(cn, "urn:node:mnStageUCSB2")
#  newid <- generateIdentifier(mn, "DOI")
#  metadataObj <- new("DataObject", id=newid, format="eml://ecoinformatics.org/eml-2.1.1", file=sampleEML)

## ---- eval=F-------------------------------------------------------------
#  addData(dp, metadataObj)

## ---- eval=F-------------------------------------------------------------
#  addData(dp, sciDataObj, metadataObj)

## ---- eval=FALSE---------------------------------------------------------
#  d1c <- D1Client(env="STAGING", mNodeid="urn:node:mnStageUCSB2")
#  packageId <- uploadDataPackage(d1c, dp, replicate=TRUE, numberReplicas=2)
#  message(sprintf("Uploaded data package with identifier: %s", packageId))

## ----eval=F--------------------------------------------------------------
#  library(digest)
#  # Create a system metadata object for a data file.
#  # Just for demonstration purposes, create a temporary data file.
#  testdf <- data.frame(x=1:20,y=11:30)
#  csvfile <- paste(tempfile(), ".csv", sep="")
#  write.csv(testdf, csvfile, row.names=FALSE)
#  format <- "text/csv"
#  size <- file.info(csvfile)$size
#  sha1 <- digest(csvfile, algo="sha1", serialize=FALSE, file=TRUE)
#  # Generate a unique identifier for the dataset
#  pid <- sprintf("urn:uuid:%s", UUIDgenerate())
#  cn <- CNode("STAGING")
#  mn <- getMNode(cn, "urn:node:mnStageUCSB2")
#  sysmeta <- new("SystemMetadata", identifier=pid, formatId=format, size=size, checksum=sha1)
#  sysmeta <- addAccessRule(sysmeta, "public", "read")

## ----eval=F--------------------------------------------------------------
#  # Create a system metadata object for a data file.
#  # Just for demonstration purposes, create a temporary data file.
#  testdf <- data.frame(x=1:20,y=11:30)
#  csvfile <- paste(tempfile(), ".csv", sep="")
#  write.csv(testdf, csvfile, row.names=FALSE)
#  format <- "text/csv"
#  size <- file.info(csvfile)$size
#  sha1 <- digest(csvfile, algo="sha1", serialize=FALSE, file=TRUE)
#  # Generate a unique identifier for the dataset
#  pid <- sprintf("urn:uuid:%s", UUIDgenerate())
#  # The seriesId can be any unique character string.
#  seriesId <- sprintf("urn:uuid:%s", UUIDgenerate())
#  cn <- CNode("STAGING")
#  mn <- getMNode(cn, "urn:node:mnStageUCSB2")
#  sysmeta <- new("SystemMetadata", identifier=pid, formatId=format, size=size, checksum=sha1,  seriesId=seriesId)
#  sysmeta <- addAccessRule(sysmeta, "public", "read")

## ----eval=F--------------------------------------------------------------
#  response <- create(mn, pid, csvfile, sysmeta)

## ---- eval=F-------------------------------------------------------------
#  cn <- CNode("STAGING")
#  mn <- getMNode(cn, "urn:node:mnStageUCSB2")
#  pid <- "urn:uuid:2fb13ee6-fb8a-4eea-b9ee-f52e85b35a7a"
#  sysmeta <- getSystemMetadata(mn, pid )
#  sysmeta <- addAccessRule(sysmeta, "public", "read")
#  status <- updateSystemMetadata(mn, pid, sysmeta)

## ---- eval=F-------------------------------------------------------------
#  # Update the object with a new version
#  updateid <- generateIdentifier(mn, "UUID")
#  testdf <- data.frame(x=1:20,y=11:30)
#  csvfile <- paste(tempfile(), ".csv", sep="")
#  write.csv(testdf, csvfile, row.names=FALSE)
#  size <- file.info(csvfile)$size
#  sha1 <- digest(csvfile, algo="sha1", serialize=FALSE, file=TRUE)
#  sysmeta@identifier <- updateid
#  sysmeta@size <- size
#  sysmeta@checksum <- sha1
#  sysmeta@obsoletes <- newid
#  response <- updateObject(mn, newid, csvfile, updateid, sysmeta)
#  updsysmeta <- getSystemMetadata(mn, updateid)

## ---- eval=FALSE---------------------------------------------------------
#  # Obtain a PID with query() or by using the member node GUI, i.e. metacatui
#  response <- archive(mn, pid)
#  newsysmeta <- getSystemMetadata(mn, pid)
#  response <- archive(mn, newid)

## ---- eval=FALSE---------------------------------------------------------
#  sysmeta <- getSystemMetadata(mn, newid)
#  str(sysmeta)

