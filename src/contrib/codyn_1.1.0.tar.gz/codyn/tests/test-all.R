library(testthat) 
library(codyn)
test_package("codyn")
