---
title: "Uploading Data to DataONE"
date: "2015-12-14"
output: rmarkdown::html_vignette
vignette: >
  %\VignetteIndexEntry{Uploading Data to DataONE}
  %\VignetteEngine{knitr::rmarkdown}
  %\usepackage[utf8]{inputenc}
---

## Introduction
  
This document describes how to use the *dataone* R package to upload data to DataONE, and how to perform
maintenance operations on the data after it has been uploaded.

DataONE provides an Application Programming Interface (API) to allow client programs to search, download, upload and
perform maintainence operations on datasets in the DataONE Federation. This API is described in the documents:

* https://purl.dataone.org/architecturev2/apis/MN_APIs.html
* https://purl.dataone.org/architecturev2/apis/CN_APIs.html

The *dataone* package provides methods to allow R scripts to call these DataONE [REST](https://en.wikipedia.org/wiki/Representational_state_transfer) services to interact with DataONE Coordinating Nodes (CN) and Member Nodes (MN), with each method calling the corresponding DataONE web service. For example, the *dataone* `listNodes` R method can call the
DataONE web service located at (https://cn.dataone.org/cn/d1/v2/nodes) and described at (https://purl.dataone.org/architecturev2/apis/CN_APIs.html#CNCore.listNodes)

The *dataone* package also provides higher level R methods that take care of many of the
details of interacting with the DataONE web services. For example, the `uploadDataPackage` method can be used to upload a set of data files
and metadata file to DataONE that will be viewable and accessible as a single
[DataONE data package](https://purl.dataone.org/architecturev2/design/DataPackage.html).

## Uploading a data package using `uploadDataPackage`
A workflow for preparing and uploading a data package using the `uploadDataPackage` method will be shown. A complete
script that uses this workflow is shown here, but each section of this script will be explained in the following sections:

```
library(dataone)
library(datapackage)
dp <- new("DataPackage")
sampleData <- system.file("extdata/sample.csv", package="dataone")
dataObj <- new("DataObject", user="uid=slaughter,o=NCEAS,dc=ecoinformatics,dc=org", format="text/csv", file=sampleData)
dataObj <- setPublicAccess(dataObj)
sampleEML <- system.file("extdata/sample-eml.xml", package="dataone")
metadataObj <- new("DataObject", user="uid=slaughter,O=NCEAS,DC=ecoinformatics,DC=org",
               format="eml://ecoinformatics.org/eml-2.1.1", file=sampleEML)
addData(dp, metadataObj)
addData(dp, sciDataObj, metadataObj)
d1c <- D1Client(env="STAGING", mNodeid="urn:node:mnStageUCSB2")
packageId <- uploadDataPackage(d1c, dp, replicate=TRUE, numberReplicas=2, quiet=F)
```

## Create a DataPackage object.
In order to use `uploadDataPackage`, it is necessary to prepare an R DataPackage that will serve as a container for the set of files that
will be included in the data package:  


```r
library(dataone)
library(datapackage)
dp <- new("DataPackage")
```
When using the `uploadDataPackage` method, data structures that are required by DataONE are created, 
maintained and uploaded automatically. These data structures include a ResourceMap that describes the data package, and SystemMetadata objects that 
contain DataONE system information for each of the science datasets and associated science metadata. 

### Prepare a metadata file that will describe the files in the data package
The next step is to prepare a metadata file that will describe the science datasets in the
datapackage. The most common metadata format used in the DataONE network is the
Ecological Metadata Langauage. Other supported formats include FGDC and ISO 19113.
Additional information about EML is available at \link{https://knb.ecoinformatics.org/#external//emlparser/docs/index.html}.

Detailed directions regarding authoring metadata documents is outside the scope of this document.

### Determine what access your data and metadata should have 
The levels of access available to objects in DataOne are "read", "write", and "changePermission".
The "read" permission allows a user the ability to view the content of a DataONE object.
The "write" permission allows a user the ability to change the content of an object via update services. 

Permissions are hierarchical, so write permission also includes read permission
The "changePermission" permission allows the ability to change the access policy for an object and includes 
both read and write permissions.

Each object in DataONE can have one or more access rules that control the access of that object. The
complete set of access rules for an object is refered to as it's access policy.

### Create a DataObject for each data file
The DataObject class is a wrapper for the science datasets and science metadata that will be uploaded and maintains information
about these objects that will be needed by DataONE.

A DataObject must be created for each science dataset and science metadata that will be uploaded to DataONE. 
A SystemMetadata object will be created automatically and stored in each DataObject. The SystemMetadata object will
be used by DataONE to maintain low level information about the dataset, such as the access policy, the user identity
of the *rightsholder* (the user identity that controls the dataset), which Member Nodes it can be replicated to, etc. More information about DataONE 
SystemMetdata is availalbe at \link{https://releases.dataone.org/online/api-documentation-v2.0.0/design/SystemMetadata.html}.

The example below creates a DataObject for a science dataset

```
sampleData <- system.file("extdata/sample.csv", package="dataone")
dataObj <- new("DataObject", user="uid=slaughter,o=NCEAS,dc=ecoinformatics,dc=org", format="text/csv", file=sampleData)
```

The *user* specified in the examples above will become the DataONE rightsholder of the dataset when it is uploaded. The rightsholder has full priviledge
to the object.

Access rules can be added to each DataObject after it has been created. Access rules can be added to grant permissions to a single user.
Access can also be granted to the *public* user, which means any and all users. For example, public read access can be set using the
`setPublicAccess` method:

```
dataObj <- setPublicAccess(dataObj)
```

Individual access rules to be applied to a DataONE user identify can also be added to the access policy. 

Access rules are added to a DataObject using the `addAccessRule` method. The following access rule will grant
user 'collins' changePermission access to the dataset after it is uploaded:

```
accessRules <- data.frame(subject="uid=jsmith,o=NCEAS,dc=ecoinformatics,dc=org", permission="changePermission")
sciDataObj <- addAccessRule(dataObj, accessRules)
```

### Create a DataObject for the metadata file
When a DataObject is created, a unique identifier is generated if one is not specified. This automatically generated
identifier has the format "urn:uuid:<a unique string>", for example "urn:uuid:c3443142-6260-4ea5-aaa1-1114981e04ad".

The following command creates the DataObject for the science metadata, using an automatically generated identifier:

```
sampleEML <- system.file("extdata/sample-eml.xml", package="dataone")
metadataObj <- new("DataObject", user="uid=slaughter,O=NCEAS,DC=ecoinformatics,DC=org", 
               format="eml://ecoinformatics.org/eml-2.1.1", file=sampleEML)
```

Alternatively, a Digital Object Identfier (DOI) may be assigned to the metadata DataObject, using the *generateIdentifier* method:

```
cn <- CNode("SANDBOX")
mn <- getMNode(cn, "urn:node:mnSandboxUCSB2")
newid <- generateIdentifier(mn, "DOI")
metadataObj <- new("DataObject", id=newid, user="uid=slaughter,O=NCEAS,DC=ecoinformatics,DC=org", 
               format="eml://ecoinformatics.org/eml-2.1.1",
               file=sampleEML)
```    

(Note that the example uses a DataONE test environment, and not the production environment.)

The `generateIdentifier` method requests that the DataONE CN generate a properly formatted DOI. 

### Add each DataObject to the DataPackage
The DataPackage object serves as a container for a set of data objects that will be uploaded to DataONE. The metadata 
DataObject and all science data DataObjects must be added to the DataPackage before calling `uploadDataPackage`.

Relationships between the objects in a DataPackage are stored in the ResourceMap which is stored in and maintained by the DataPackage.
One type of relationship that is stored is between the science metadata and the science datasets that are described by
it. In the [DataONE data package](https://purl.dataone.org/architecturev2/design/DataPackage.html) implementation, this
relationship is the [CITO](htts://http://vocab.ox.ac.uk/cito) *documents* relationship that links the metadata object
to the science object.

This relationship between the science metadata and science data objects will be made automatically for each science 
data object as it is added to the DataPackage, if the metadata object is included when the science data object is
added.

Now add the metadata object to the DataPackage:

```
addData(dp, metadataObj)
```

Then specify the metadat object when each science data object is added:

```
addData(dp, sciDataObj, metadataObj)
```

### Upload the DataPackage

When all DataObjects have been added to the DataPackage, call the `uploadDataPackage` method to upload the 
entire DataPackage:

```
d1c <- D1Client(env="SANDBOX", mNodeid="urn:node:mnSandboxUCSB2")
packageId <- uploadDataPackage(d1c, dp, replicate=TRUE, numberReplicas=2)
message(sprintf("Uploaded data package with identifier: %s", packageId))
```

(Note that the example uses a DataONE test environment, and not the production environment.)

After uploadDataPackage has been called sucessfully, the data package can be viewed on the member node, searched for
using the DataONE search facility. Note that if objects in DataONE are not publicly readable, and the authenticated
user performing the search isn't granted access in an object's access policy, then the objects will not be 
viewable or discoverable via the search facility.

## Uploading Individual Datasets And Metadata
[Not yet completed]
## Maintaining Uploaded Datasets
[Not yet completed]
<!--
After datasets and their metadata have been uploaded to DataONE, maintenance operations can be performed on these objects using the methods described in the following sections:

* Update the DataONE system metadata for an object (MNode: updateSystemMetadata)
Provides a mechanism for updating system metadata for any objects held on the Member Node where that Member Node is the authoritative Member Node. 

* Replace an object with a newer version (MNode: update)
Updates an existing object by creating a new object identified by newPid on the Member Node which explicitly obsoletes the object identified by pid through appropriate changes to the SystemMetadata of pid and newPid.

The Member Node sets Types.SystemMetadata.obsoletedBy on the object being obsoleted to the pid of the new object. It then updates Types.SystemMetadata.dateSysMetadataModified on both the new and old objects. The modified system metadata entries then become available in MNRead.listObjects(). This ensures that a Coordinating Node will pick up the changes when filtering on Types.SystemMetadata.dateSysMetadataModified.

The update operation MUST fail with Exceptions.InvalidRequest on objects that have the Types.SystemMetadata.archived property set to true.

A new, unique Types.SystemMetadata.seriesId may be included when beginning a series, or a series may be extended if the newPid obsoletes the existing pid.
-->

### Remove an object from DataONE search (MNode: archive)
[Not yet completed]
<!--
Hides an object managed by DataONE from search operations, effectively preventing its discovery during normal operations.

The operation does not delete the object bytes, but instead sets the Types.SystemMetadata.archived flag to True. This ensures that the object can still be resolved (and hence remain valid for existing citations and cross references), though will not appear in searches.

Objects that are archived can not be updated through the MNStorage.update() operation.

Archived objects can not be un-archived. This behavior may change in future versions of the DataONE API.

Member Nodes MUST check that the caller is authorized to perform this function.

If the object does not exist on the node servicing the request, then an Exceptions.NotFound exception is raised. The message body of the exception SHOULD contain a hint as to the location of the CNRead.resolve() method.

-->
