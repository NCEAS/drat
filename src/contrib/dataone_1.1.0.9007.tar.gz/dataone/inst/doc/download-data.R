## ---- warning=F----------------------------------------------------------
library(dataone)
cn <- CNode("PROD")
# Ask for the id, title and abstract
queryParams <- list(q="abstract:kelp", fq="attribute:abundance", fq="formatType:DATA", fl="id,title,abstract") 
result <- query(cn, solrQuery=queryParams, as="data.frame", parse=FALSE)

## ---- warning=F----------------------------------------------------------
 pid <- result[6,'id']

## ---- warning=F, error=F, cache=pid--------------------------------------
locations <- resolve(cn, pid)
mnId <- locations$data[1, "nodeIdentifier"]
mn <- getMNode(cn, mnId)

## ---- warning=F, cache=pid,mn--------------------------------------------
obj <- get(mn, pid)

## ---- warning=F----------------------------------------------------------
# Query the data holdings on a member node
cn <- CNode("PROD")
mn <- getMNode(cn, "urn:node:KNB")
queryParams <- list(q="abstract:habitat", fl="id,title,abstract") 
result <- query(mn, queryParams, as="data.frame", parse=FALSE)
# Choose the first matchin PID
pid <- result[1,'id']
obj <- get(mn, pid)

## ---- warning=F----------------------------------------------------------
d1c <- D1Client("PROD", "urn:node:KNB")
# Ask for the id, title and abstract
queryParams <- list(q="abstract:kelp", fl="id,title,abstract") 
result <- query(cn, solrQuery=queryParams, as="data.frame", parse=FALSE)
pid <- result[6,'id']
dataObj <- getDataObject(d1c, pid)

