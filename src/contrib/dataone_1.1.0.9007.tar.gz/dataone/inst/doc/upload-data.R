## ---- warning=F, message=F-----------------------------------------------
library(dataone)
library(datapackage)
dp <- new("DataPackage")

