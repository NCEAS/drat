context("Stress tests")
test_that("Stress Test", {
  library(redland)
  library(uuid)
  
  for (i in 1:1000) {
    uuid <- UUIDgenerate()
    
    world <- new("World")
    expect_that(world, not(is_null()))
    
    # Test creating the Storage system
    storage <- new("Storage", world, "hashes", name="", options="hash-type='memory'")
    expect_that(storage, not(is_null()))
    expect_that(class(storage@librdf_storage), matches("_p_librdf_storage_s"))
    
    # Test creating the Model
    model <- new("Model", world, storage, options="")
    expect_that(model, not(is_null()))
    expect_that(class(model@librdf_model), matches("_p_librdf_model_s"))
    
    # Test that model creation fails if world is not provided or is null
    err <- try(model <- new("Model", world=NULL, storage, options=""), silent=TRUE)
    expect_that(class(err), matches("try-error"))
    
    expect_that(model, not(is_null()))
    expect_that(class(model@librdf_model), matches("_p_librdf_model_s"))
    
    # Test adding a Statement to the Model
    subject <- new("Node", world, uri=sprintf("http://www.johnsmith.com/john-%s", uuid))
    expect_that(class(subject@librdf_node), matches("_p_librdf_node_s"))
    
    predicate <- new("Node", world, uri=sprintf("http://purl.org/dc/elements/1.1/creator-%s", uuid))
    expect_that(class(predicate@librdf_node), matches("_p_librdf_node_s"))
    
    object <- new("Node", world, literal=sprintf("John Smith-", uuid))
    expect_that(class(object@librdf_node), matches("_p_librdf_node_s"))
    
    statement <- new("Statement", world, subject, predicate, object)
    expect_that(statement, not(is_null()))
    expect_that(class(statement@librdf_statement), matches("_p_librdf_statement_s"))
    addStatement(model, statement)
    
    # Test creating a Serializer
    serializer <- new("Serializer", world, mimeType="application/rdf+xml")
    expect_that(serializer, not(is_null()))
    expect_that(class(serializer@librdf_serializer), matches("_p_librdf_serializer_s"))
    
    # Test adding a namespace to a serializer
    status <- setNameSpace(serializer, world, namespace="http://purl.org/dc/elements/1.1/", prefix="dc")
    expect_that(status, equals(0))
    
    # Test serialization of an RDF model to a string
    rdf <- serializeToCharacter(serializer, world, model, "")
    expect_that(rdf, matches("John Smith"))
    rm(rdf)
    
    # Test serialization of an RDF model to a file
    filePath <- tempfile(pattern = "file", tmpdir = tempdir(), fileext = ".rdf")
    status <- serializeToFile(serializer, world, model, filePath)
    found <- grep("John Smith", readLines(filePath))
    expect_that(found, is_more_than(0))
    unlink(filePath)
    freeStatement(statement)
    rm(statement)
    freeModel(model)
    rm(model)
    freeSerializer(serializer)
    rm(serializer)
    freeStorage(storage)
    rm(storage)
    freeWorld(world)
    rm(world)
  }
  #     err <- try(freeStatement(statement), silent=TRUE)
  #     expect_that(class(err), not(matches("try-error")))
  #     
  #     err <- try(freeSerializer(serializer), silent=TRUE)
  #     expect_that(class(err), not(matches("try-error")))
  #     
  #     err <- try(freeModel(model), silent=TRUE)
  #     expect_that(class(err), not(matches("try-error")))
  #     
  #     err <- try(freeStorage(storage), silent=TRUE)
  #     expect_that(class(err), not(matches("try-error")))
  #     
  #     err <- try(freeWorld(world), silent=TRUE)
  #     expect_that(class(err), not(matches("try-error")))
  
})