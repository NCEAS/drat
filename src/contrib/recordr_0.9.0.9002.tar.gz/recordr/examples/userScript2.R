
a <- 0
b <- "cat"
print("I'm user script #2")

#cm <- CertificateManager()
cli <- D1Client("SANDBOX", "urn:node:mnSandboxUCSB1")
item <- getD1Object(cli, "doi:10.6085/AA/pisco_intertidal_summary.42.3")

cat(sprintf("Got D1Object, pid: %s", getIdentifier(item)))
print("userScript2.R done")
