library(dataone)

# Example script that reads a CSV in and then writes it out.

inFile <- system.file("extdata/testData.csv")
df <- read.csv(file = "./coverages_2001-2010.csv")

# Save local file
write.csv(df, file = tempfile(pattern = "file", tmpdir = tempdir(), fileext = ".csv"))
