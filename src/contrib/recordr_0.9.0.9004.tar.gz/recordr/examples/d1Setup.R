
# library(dataone)

install.packages("/Users/slaughter/Projects/DataONE/dataone_r/v1.0.0/dataone_1.0.0.tar.gz", repos = NULL, type="source")
install.packages("/Users/slaughter/Projects/DataONE/dataone_r/v1.0.0/dataonelibs_1.0.0.tar.gz", repos = NULL, type="source")

install.packages("/Users/slaughter/Projects/DataONE/dataone_r/v1.1.0/dataone_1.1.0.tar.gz", repos = NULL, type="source")
install.packages("/Users/slaughter/Projects/DataONE/dataone_r/v1.1.0/dataonelibs_1.1.0.tar.gz", repos = NULL, type="source")

install.packages("/Users/slaughter/Projects/R/rdataone/dataone_1.4.0.tar.gz", repos = NULL, type="source")
install.packages("/Users/slaughter/Projects/R/rdataone/dataonelibs_1.4.0.tar.gz", repos = NULL, type="binary")

install.packages("/Users/slaughter/Projects/R/rdataone/dataone_1.4.1.tar.gz", repos = NULL, type="source")

# From Carl
devtools::install_github("ropensci/rdataone", subdir='dataone')

library(dataone)
library(testthat)
library(RCurl)
library(httr)

cm <- CertificateManager()
downloadCert(cm)
getCertExpires(cm)

cli <- D1Client("SANDBOX", "urn:node:mnSandboxUCSB1")
results <- d1SolrQuery(cli, list(q="kelp",fl="identifier,etc..."))
# Query result returned as an xml document
xml1 = xmlParse(results)
# Get xml nodes for the returned identifiers
ns1 <- getNodeSet(xml1, "/response/result/doc/str[@name='identifier']")
# Get the text value of the xml node for one identifier
nv1 <- xmlValue(ns1[[1]])

# Do all of the above in one call
d1IdentifierSearch(cli, "q=kelp")

# Download a single D1 object
#item <- getD1Object(cli, "doi:10.6085/AA/ELLXXX_015MTBD003R00_20040828.40.1")
item <- getD1Object(cli, "doi:10.6085/AA/pisco_intertidal_summary.42.3")
# Pull out data as a data frame
df <- asDataFrame(item)

# detach("package:dataone")
# clean everything from the environment
# rm(list = ls())

file.sources = list.files(pattern="*.R")
sapply(file.sources,source,.GlobalEnv)

source("MNode.R")
mn_uri <- "https://knb.ecoinformatics.org/knb/d1/mn/v1"
mn <- MNode(mn_uri)
res <- listQueryEngines(mn)

# Creating packages
install.packages("devtools")
library("devtools")
devtools::install_github("klutometis/roxygen")
library(roxygen2)

# Creating functions
foo <- function(x) {
  mean(x)
}

setGeneric("setwd")

setMethod("setwd", signature=("character"), function(dir) {
  print("Hi i'm in setw#' @export
setGeneric("foo", function(node, id) {
  standardGeneric("foo")
})d")
  base::setwd(dir)
})

setMethod("setwd", signature=("character", re"integer"), function(dir) {
  print("Hi i'm an integer")
  base::setwd("..")
})


#' @export
setGeneric("foo", function(node, id) {
  standardGeneric("foo")
})


setMethod("foo", signature("CNode", "character"), function(node, id) {
  print("CNode foo")
})


setMethod("foo", signature("MNode", "character"), function(node, id) {
  print("MNode foo")
})

