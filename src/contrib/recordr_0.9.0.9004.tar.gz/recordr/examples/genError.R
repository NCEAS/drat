#library(dataone)

# This test script can be used to test the 'record' method of the recordr package.
print("Message from script before executing bad read\n")
df <- read.csv(file = "doesnotexist.csv")
print("Message from script after exectuing bad read - did we reach it?\n")

