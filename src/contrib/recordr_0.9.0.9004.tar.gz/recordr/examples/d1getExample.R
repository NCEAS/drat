library(dataone)

#
cm <- CertificateManager()
getCertExpires(cm)

cn <- CNode("STAGING2")                  # Use Testing repository
mn <- getMNode(cn, "urn:node:mnTestKNB")    # Use Testing repository

pid <- "urn:uuid:13ce246c-82a9-4c90-9828-95d80b752e8e"
pid <- URLencode(pid)
ds <- get(mn, pid)
#dsSM <- getSystemMetadata(mn, pid)
#print(dsSM)

dst <- rawToChar(ds)
dsdf <- read.table(text=dst, sep=",")

outFile <- tempfile(pattern = "file", tmpdir = tempdir(), fileext = ".csv")
write.csv(dsdf, file=outFile)
cat(sprintf("Saved DataONE dataset to file %s\n", outFile))

