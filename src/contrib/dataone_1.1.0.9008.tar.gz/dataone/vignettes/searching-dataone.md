---
title: "Searching DataONE Data Holdings"
date: "2015-12-14"
output: rmarkdown::html_vignette
vignette: >
  %\VignetteIndexEntry{Searching DataONE Data Holdings}
  %\VignetteEngine{knitr::rmarkdown}
  %\usepackage[utf8]{inputenc}
---

The primary method to locate data in the DataONE network is to use the web based search tool located at https://search.dataone.org.

Data can also be discovered programatically from R using the DataONE R client method `query()`. Both methods access the same
underlying search mechanism, the Apache Foundation Solr search engine that runs on the DataONE Coordinating Node (CN) located at
(https://cn.dataone.org/cn). The DataONE Solr index (similar to a catalog or database) contains infrormation for every dataset that is available from 
the DataONE network. 

Information about the Solr search engine can be obtained at [Solr Resources](http://lucene.apache.org/solr/resources.html) and 
[Solr Tutorial](http://www.solrtutorial.com)

Additional information about searching DataONE can be viewed at [Content Discovery](https://mule1.dataone.org/ArchitectureDocs-current/design/SearchMetadata.html).

## Using The `query` Method

Some familiarity with Solr is helpful to use the `query` method
effectively, however basic queries can be very powerful and the examples in this document can provide a starting point. Also, it is possible to use the `query` method just specifying name, value pairs (See the section: *A Simplied Search")


Additional information about the `query` method can be obtained from the R help facility, e.g. `?query` from the R command line.

## Query and return an R list

The following example queries DataONE and return values in an R list, with each value converted from the Solr result to the appropriate R data type: 


```r
library(dataone)
cn <- CNode("PROD")
queryParamList <- list(q="id:doi*", rows="2", fq="abstract:chlorophyll", fl="id,title,dateUploaded,abstract,datasource,size")
result <- query(cn, solrQuery=queryParamList, as="list")
```

The `result` object contains all the data values returned from the query. Each element of the returned list contains information
for one dataset. Each returned attribute for a dataset can be accessed with the appropriate element name, for example, to 
access the title information of the first dataset returned, use the R statement:


```r
message(sprintf("Title: %s", result[[1]]$title))
```

```
## Title: Bisley/Prieta Algae Monitoring
```

To print out selected information for all returned values, use:


```r
ids <- lapply(result, function(x) {
  message(sprintf("id: %s", x$id))
  message(sprintf("origin member node: %s", x$datasource))
  message(sprintf("title: %s", x$title))
  message(sprintf("date uploaded: %s", x$dateUploaded))
  x$id
})
```

```
## id: doi:10.6073/AA/knb-lter-luq.136.2
## origin member node: urn:node:LTER
## title: Bisley/Prieta Algae Monitoring
## date uploaded: 2009-04-29
## id: doi:10.6073/AA/knb-lter-arc.178.1
## origin member node: urn:node:LTER
## title: 94isrchl.txt
## date uploaded: 2005-07-27
```
  
The complete list of possible values stored for a dataset can be viewed at [DataONE Solr Engine Description](https://cn.dataone.org/cn/v1/query/solr). However,
the values available for a particular dataset may be a subset of these, depending on the metadata provided when the dataset is uploaded to DataONE.

### Return values as a data frame
To return results as a data frame, use the `as` parameter as shown below. In addittion all values will be stored as `character`, because `parse=FALSE` is specified:


```r
cn <- CNode("PROD")
result <- query(cn, queryParamList, as="data.frame", parse=FALSE)
```

The `result` is a data frame with each row containing information for one dataset. To print all returned DataONE identifiers from the result:
  

```r
result[,'id']
```

```
## [1] "doi:10.6073/AA/knb-lter-luq.136.2" "doi:10.6073/AA/knb-lter-arc.178.1"
```

### Using a Simplified Search.
A search may be performed by just specifying query fields and values using the \code{'searchTerms'} parameter.
For example, to search for datasets that mention 'kelp' in the abstract and have an attribute discription that contains the word 'biomass', the following query could be used:

```r
cn <- CNode("PROD")
mn <- getMNode(cn, "urn:node:mnKNB")
mySearchTerms <- list(abstract="kelp", attribute="biomass")
result <- query(cn, searchTerms=mySearchTerms, as="data.frame")
```

Using the \code{'searchTerms'} parameter causes the \code{'query'} method to construct a Solr query 
based on the list, that is passed on to the DataONE node specified.

The names in the *searchTerm* list are the query field names available from the Solr query engine
being used. These names can be determined using the *queryEngineDescription* method, or simply
navigating a web browser to the appropriate link. For the example above, the query engine
description can be found at https://knb.ecoinformatics.org/knb/d1/mn/v1/query/solr.

## Search the entire DataONE network
[To be completed]

## Search just a member node
[To be completed]

### Filter query results for a specific member node
In order to limit a search to data holdings that originated from a specific member node a Solr filter query parameter (`&fq`) can be used
for the `datasource` field:


```r
cn <- CNode("PROD")
queryParams <- 'q=id:*&fl=id,title&fq="datasource:urn:node:KNB"&rows=5'
result <- query(cn, queryParams, as="data.frame", parse=FALSE)
result[,'id']
```

```
## [1] "df35d.3.2"            "sclark.66.12"         "apramus.4.14"        
## [4] "doi:10.5063/F1Q23X56" "kgordon.31.64"
```
  
